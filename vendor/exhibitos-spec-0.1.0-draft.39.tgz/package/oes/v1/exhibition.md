# OES Exhibition and lifecycle draft

Version **1.0.0-draft.1**. These schemas define portable documents and validation;
they do not implement Studio, Viewer, physics, navigation mesh, audio playback,
scripting execution or a production publication service. The fixture is original
synthetic data. All new schema/example/code/docs files use Apache-2.0; the existing
four CC0 fixture files remain unchanged.

The version1 `org.exhibitos.studio/architectural-finishes` wall metadata may
explicitly include `plainBaseboard: true` only with `preset: "plain"`. Absent or
false retains the existing plain-wall behavior. The opt-in uses the existing
bounded `baseboardHeight`; it requests only a lower band, never opening trim or
a ceiling band. It does not change structural depth, aperture, or portal fit.
Consumers must qualify and exclude any supported portal-foot intersection in
the same geometry used for rendering and collision. Unsupported portal profiles
must not fall back to guessed bounds. Structural metadata acceptance alone does
not establish that geometry, source bytes, or appearance are qualified. Older
consumers with closed wall-field validation require a matched update before
using the new optional field; no automatic migration or installation is implied.

## Independent validation

Use Node24.21.0/npm11.19.0 and `npm ci --ignore-scripts`, then:

```sh
npm run check
npm run validate:exhibition -- revision oes/v1/examples/exhibition.json --assets fixtures/synthetic --at 2026-10-01T01:00:00Z
npm run validate:exhibition -- draft oes/v1/examples/draft.json --assets fixtures/synthetic
npm run validate:exhibition -- publication oes/v1/examples/publication.json --revision oes/v1/examples/exhibition.json --assets fixtures/synthetic
npm run validate:exhibition -- freeze oes/v1/examples/freeze.json --revision oes/v1/examples/exhibition.json --publication oes/v1/examples/publication.json --assets fixtures/synthetic
```

Exit status and JSON result match the Artwork CLI. Explicitly empty `--assets`
values are rejected; only omitting the option selects document-only mode. Forbidden
options are rejected by their presence, including empty string values. Schema IDs are immutable
identities resolved locally; no network fetching or private repository is required.
The frozen example's zero runtime image digest and synthetic runtime version are
explicit placeholders illustrating binding fields, not evidence an OCI image exists
or that a frozen exhibition can currently be reconstructed.

Library entry points in `validators/exhibition.mjs`:
`validateExhibition`, `validateExhibitionFiles`, `validateLifecycle`,
`validateLifecycleFiles`, `sealDraft`, `revisionHash` and `assetInventory`.

Validation has distinct scopes:

| Scope | Established | Still required by a publication service |
| --- | --- | --- |
| Schema | Shape, supported exact version, bounded fields | References, rights and files |
| Document/semantic | References, normalized transforms, door graph, rights at supplied time, declared revision hash | Actual file integrity and current ownership/authorization |
| `--assets` | Document checks plus declared artwork file size/hash/signature and GLB conformance | Quarantine/isolated decoding, tenant authorization, current grant revocation, actual runtime |

An untrusted `validated` property is rejected and cannot serve as proof. The
publication validator revalidates the supplied revision and its rights, and compares
its computed hash every time. Production publish must also run file verification
and current authorization checks. `sealDraft` returns a deeply frozen independent
copy and explicitly says `validationScope: document-only`; it does not establish
binary integrity or durable database immutability.

## Coordinates and references

Room dimensions are width X, height Y and depth Z in meters. Room-local bounds are
X±width/2, Y0..height, Z±depth/2. Room transform maps local coordinates to exhibition
world space. Surface, placement, light and waypoint coordinates are local to their
owning room. Room/surface/light scale is identity; placement scale is positive.
All rotations use normalized XYZW quaternions, tolerance 1e-6.

Surfaces have a center transform and rectangular width/height in their own XY
plane, with normal +Z before rotation. Their center must be inside the owning room.
Doors/windows attach to a wall surface, using centered local XY offset and a
positive rectangular size that fits inside that surface. This is a coordinate and
graph contract; it does not prove surface polygons lie on boundaries, doors align
physically across transformed rooms, artwork volumes fit, or geometry is walkable.

A door has exactly one reciprocal door endpoint in a different room or
`exterior: true`. A window has neither graph endpoint nor exterior flag. Navigation
waypoints contain room-local positions. A room transition names the door in the
previous room via `viaOpeningId`; its reciprocal endpoint must belong to the next
room. Waypoints in one room omit this field. The validator checks graph consistency,
not collision-free paths or accessible physical widths.

Collections have unique UUID IDs, compared case-insensitively for references.
Artworks embed complete immutable Artwork snapshots indexed by revision ID.
Placements reference a snapshot and a display asset belonging to that snapshot.
The same artwork may have multiple placements, each with its own unique placement
ID/transform. Apply the artifact transform first, then placement, then room; recorded
source-unit conversion is already baked in and must not be applied again.

An asset ID or relative path reused across snapshots must retain exact path,
size, SHA-256 and MIME. Freeze uses a unique inventory sorted lexically by lowercased
asset ID. Total unique declared bytes are capped at 256MiB. File-mode verification
may inspect a shared artwork asset set once; its result does not substitute for
validating every snapshot's rights and metadata.

## Lighting and accessibility

Point/spot intensity uses candela, directional uses lux and area uses lumen.
Spot additionally requires beamAngle (0..π/2 exclusive at zero); area requires
positive rectangular dimensions. Other light types omit those parameters. Color
is linear RGB in [0,1]. A target placement, if present, belongs to the light's room.
This contract does not claim renderer photometric calibration.

Accessibility explicitly records list alternative, keyboard navigation, reduced
motion and stationary navigation requirements, plus accessible route references
and one plain-text description per placement. Dangling/duplicate references or
missing descriptions are rejected. These are declared requirements for future
consumers, not proof of browser accessibility compliance or user testing.

## Draft, revision, publication and freeze

- Draft envelope owns a mutable editVersion, creation/update times and a candidate
  revision; optional baseRevisionId preserves the fork source. Candidate validation
  can fail during editing/preview. `sealDraft` accepts only a valid candidate and
  creates an immutable copy. Storage owns revision UUID uniqueness and sequencing.
- Exhibition revision is an immutable artifact with stable exhibition ID, revision
  UUID and positive sequence. Editing published content creates a new draft/revision,
  rather than mutating the referenced snapshot.
- Publication contains exhibition/revision IDs, exact revision hash, publication
  time and published/unpublished status. Unpublished status requires a non-earlier
  unpublishedAt; published status forbids that field. Anonymous consumers read
  only approved immutable pointers. Current grants and tenant ownership must still
  be checked by the platform; document validation is not an authorization token.
- Freeze binds this active publication, revision hash, exact asset inventory,
  runtime image SHA-256 digest, runtime version, DB migration version and exact OES
  versions. OEX/OED are `not-used` in this draft because their contracts do not exist
  yet. These pins describe preservation inputs; backup/restore and reconstruction
  are separate tasks. A freeze cannot precede publication and needs valid display
  rights at its own instant.

All timestamps share the Artwork profile: calendar-valid UTC with uppercase T/Z,
seconds00–59 and optional1–3 fractional digits, plus finite instant parsing. Leap
seconds and sub-millisecond precision are rejected. Display grants include validFrom
and exclude expiresAt. Publication time is checked even for an empty exhibition.

## Hash and JSON profile

`oes-sorted-json-v1` recursively sorts object keys by JavaScript UTF-16 lexical
order, preserves dense array order, uses JSON.stringify for primitive encoding and
UTF-8 without whitespace/BOM, then SHA-256. Object key order and source whitespace
do not matter; content and array order do. This project profile is not a claim of
RFC8785/JCS conformance. Use `revisionHash`; hashing the source text is different.

Only finite numbers, well-formed Unicode strings, null/booleans, dense arrays with
no extra properties and plain objects with enumerable string-keyed data properties
are accepted. Cycles, accessors, symbols, sparse arrays and exotic prototypes are
rejected. Input is capped at1MiB, JSON depth32,100000 traversed nodes and16384 code
units per string; errors are capped100. Namespaced extensions preserve unknown
objects but are each capped16KiB, including embedded Artwork extensions. Core
objects reject unknown properties. Consumers must escape all text for display.

## Reserved audio, annotations and scripts

Audio assets use bounded local relative paths, exact hashes/size, explicit rights
and MIME declarations. Zones require a local room center/radius, volume[0,1],
plain-text transcript and autoplay=false. File-mode audio validation is explicitly
unsupported and returns a rejection rather than claiming byte verification.
Audio decoding/playback and consent UI are later tasks.

Annotations contain bounded plain text tied to a placement. Scripts are stored,
**disabled** declarations only: room-enter/exhibition-start triggers and typed
light-intensity/show-annotation/play-audio actions. Targets must resolve; delay is
0..60000ms, maximum32 actions/script and1024 actions/exhibition. No arbitrary JS,
HTML, external URL or network fetch is part of these core contracts. A future
execution contract must define permission, CPU/time, scheduling and cancellation
budgets before enabling scripts; unknown extensions cannot bypass these rules.

## Reusable rectangular portal fit

Package draft.29 adds the explicit `rectangular-portal-v1` geometry alternative
to workspace furnishings v7. Existing continuous and modular profiles keep their
prior meaning. Earlier readers reject the unknown profile; no saved source or
legacy attachment is rewritten. OEX draft.19 carries the same source-bound fit
receipt and opening attachment.

The producer measures a closed, untextured continuous U-section with a 45 mm
surround, floor-centred origin and no sill. It binds measured opening dimensions
and asymmetric Z bounds to the exact original digest and byte count. Names and
hash allowlists do not establish this eligibility. Unsupported geometry, textures
or sections are refused rather than approximated. The original GLB and its rights
remain unchanged; the renderer owns only an adapted geometry copy.

Targets are floor-level rectangular doors, .9–3 m wide and 2–3.2 m high, with
enough solid wall for the surround and no neighbouring opening intersection.
An independent target requires one plain wall finish, .03–.2 m thick. The
reciprocal target currently supports only the measured 2.4 × 3 m paired-wall
relationship already checked by `pairedPortalFit`; its finished reveal is
[-.082,+.060] m in the Arrival host coordinates. One attachment on that host
represents the physical pair. The finish never creates or enlarges an opening,
changes the existing passage collision, or inserts a full-box collider or sill.

Width and height adaptation preserve the 45 mm section and rectangular corners;
depth adaptation covers the checked finished faces. This profile admits no
textures, so it does not claim texture-scale adaptation. Registration, current
ownership, display/export rights, live capability admission and actual walking
and visual qualification remain consumer responsibilities.

A version 1 modular portal descriptor with source-bound measured rails fits a
reciprocal opening at a coincident room boundary. Both 120 mm walls must be
upright, full inward-facing boundaries of the same height. Each wall has one
matching floor-level aperture inside their world overlap. Their actual common
opening is 1.1–2.4 m wide and 2.2–3 m high, with room for the 40 mm surround
on both walls. The attachment host is plain and its peer is painted-edge.
The reveal follows the structural depth union. Each room draws its inward face
and finish over the shared span. Exposed wall ends keep both faces and finishes.
One attachment and reveal represent the pair, with the original aperture and
both collision slabs intact.

The measurement binds the modular recipe to the original model's size and
digest. Registration and publication still verify actual source bytes and
applicable rights. IDs may be remapped in OEX or public output without changing
that binding. The existing 2.4 × 3 m coincident double-width placement remains
valid. Inset and standalone fit rules retain their existing limits. This uses
the existing descriptor, attachment fields and wire schemas.


### Architectural wall-finish capacity

The existing `org.exhibitos.studio/architectural-finishes` version 1 namespace admits at most 20 unique existing wall faces. The portal validator applies the same finite row bound while retaining each wall’s closed fields, depth and paired-finish requirements. This capacity increase does not introduce a new namespace or OEX format, change wall geometry, or authorize ignoring artwork obstruction, source, rights or save validation. Shared Studio consumers retain the 8 KiB metadata, 8 openings per wall and 256 generated boxes / 3072 triangles limits. Earlier saved documents remain valid; consumers that still enforce 8 rows must be updated before consuming larger namespaces.

### Workspace furnishing v10: canonical image contact

Version10 preserves all v9 source geometry and permits an optional closed `imageFit` on each frame attachment. Legacy rows without it retain their earlier fit. The only issued policy is `{version:1, profile:"contain-contact-v1", sourceSha256, pixelWidth, pixelHeight}`. Its parent attachment binds the artwork revision and approved primary asset; its SHA must equal that primary PNG descriptor. Pixel extents are positive integers up to8192 per edge and25165824 total pixels. The producer verifies these extents against the actual approved immutable PNG before issuing or saving a changed record. Public document validation alone does not inspect image bytes or grant rights.

Package draft.34 adds a narrow metric placement-scale qualification for namespace10 measured straight-ring and straight-miter attachments. Artwork and room scales remain exactly unit; artwork rotation must be quaternion identity (either sign), and placement scale must have finite positive X/Y components within the existing affine range and Z exactly1. Placement and room rotations remain valid unit quaternions. Declared and effective target dimensions must stay within the existing measured-fit bounds. Old namespaces, non-unit artwork/room/Z scales, reflected/singular transforms and rotated-artwork combinations remain unsupported. No stored transform, artwork dimension, pixel, source model or identity is normalized or rewritten.

Consumers use `qualifiedFrameAttachmentTransform` and `frameAttachmentMetricFit`. The latter returns metric corner translations and `rigidFrame:true` only for a qualified non-unit placement. The frame renderer retains the full composed frame position and orientation, removes scale from the frame pose only, and fits the loader-owned ring opening to the effective image footprint. Rail width, bevels, depth and image-plane Z therefore remain in metres. The artwork keeps its original full transform. Contact rows keep zero ideal aperture gap; legacy rows keep their3mm metric gap. Unit-scale attachments return the exact earlier fit path with `rigidFrame:false`. A rejected metric fit must never fall back to an unscaled or stretched frame. Namespace and imageFit wire shapes are unchanged; draft.33 consumers can reject these newly qualified non-unit attachments and must not be used to render them.

The canonical aspect is that approved primary bitmap's aspect, independent of loaded coarse/full tier rounding. A contained footprint preserves the physical artwork dimensions as its bounds and preserves the full image UV extent, including photographic margins. All issued records for one artwork revision/primary must agree; conflicting or stale records are errors, not array-order choices or legacy fallbacks. Measured straight-ring/miter sources only are eligible.

The contact aperture equals that canonical footprint, with zero ideal positive clearance; `1e-6`m is numerical comparison tolerance only. The source rail/corner geometry, UVs, normals, image-plane Z, source bytes and rights remain unchanged. No crop, mat, backing or arbitrary physical-dimension scaling is introduced. Physical-dimension and measured-profile limits still apply to both the target and canonical footprint.

A supported reconcile operation upgrades one existing attachment and the namespace, never its furnishing descriptor. An already identical authoritative record is an idempotent no-op. Source/revision/primary changes require a fresh approved binding, not silent metadata repair. Gallery image lookup is artwork-level because images may be shared across placements; contact fit remains attachment-specific. OEX draft22 carries v10 without downgrading or reinterpreting old v9 archives.
